//This function will allow the user to add to my cart
//-------------------------------------------------------------------------------------

function ItemAppear()
{
  $("table").toggle(function unhide()
  {
    $("table").display=block;
  }
  );

}

function ItemGone()
{
  $("table").toggle(function hide()
  {
    $("table").display=none;
  }
  );
}
