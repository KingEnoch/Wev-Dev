Web Dev Assignment

Enoch Oppong and Vlads Drobovics

Installation guide
Step 1 make sure that you have got Sql lite installed version 3.33.0 or higher.
Step 1.1 Make sure you have the sql lite in the path video link here on how to do it for windows (https://www.youtube.com/watch?v=wXEZZ2JT3-k&t=311s)
Step 2 Make sure you have the jquery version 3.5.1 with in case you don't, don't worry we have a jquery javascript file in the js (if your internet is down)
Step 3 You will be given a zipped file of all the html,css,javascript and images. Unzip the folder.
Step 4 make sure you have node js installed and nodemon.
Step 5 Enjoy. 

