const express = require('express');
const bodyParser = require('body-parser');

const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('cakeshop.db');

const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const {body, validationResult} = require('express-validator'); 

//For the login
const user = 'user';
const password = 'passw';

const bcrypt = require('bcrypt');
const saltRounds = 10;

	

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/public"));
//Development Settings *NEW*
app.use(session({
	secret: 'Random string to sign the cookie.',
	resave: false,
	saveUninitialized: false,
}));
app.use(passport.initialize());
app.use(passport.session());


passport.use(new LocalStrategy(
	function(username, password, done) {
		const query = db.prepare('SELECT email, passwd FROM subscribers WHERE email = $1;');
		query.get(username, function(err, row){
			if (err) { return done(err); }
			if (!row) { return done(null, false, {message: 'User not found.'}); }
			bcrypt.compare(password, row.passwd, function(err, result){
				if (result == true){
					done(null, {id: row.email});
				}	
				else{
					return done(null, false, {message: 'Incorrect password'});
				}	
			});  
		});
	}
));

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
	const query = db.prepare('SELECT email FROM subscribers WHERE email = $1;');
	query.get(id, function(err, row){
		done(err, row);
	});
});


app.listen(3000, function() {
    console.log("Server running on port 3000");
});

app.get('/about', function(req, res){
	res.sendFile(__dirname + "/about.html");
});

app.get('/addon', function(req, res){
	res.sendFile(__dirname + "/addon.html");
});

app.get('/contact', function(req, res){
	res.sendFile(__dirname + "/contact.html");
});

app.get("/", function(req, res){
	res.sendFile(__dirname + "/index.html");
});

app.get('/login', function(req, res) {
    res.sendFile(__dirname + "/login.html");
});

app.post('/login', function(req, res, next) {
  passport.authenticate('local', function(err, user, info) {
    if (err) { 
		console.log(err);
		return next(err); 
	}
    if (!user) {
		console.log(info)	
		return res.redirect('/login'); 
	}
    req.logIn(user, function(err) {
		if (err) { 
			console.log(err);
			return next(err); 
		}
        return res.redirect('/');
    });
  })(req, res, next);
});


app.post('/insertSubscriber', [
	body('fname').isLength({min: 3, max: 50}),
	body('email').isLength({min: 3, max: 50}).isEmail(),
	body('passwd').isLength({min: 3, max: 50})
	
],
function(req, res){
	const validErrors = validationResult(req);
	
	if(!validErrors.isEmpty()){
		console.log(validErrors);
		res.status(400).json({errors: validErrors.array()})
	}
	else{
		const fname = req.body.fname;
		const email = req.body.email;
		const passwd = req.body.passwd;
		console.log(`${fname} ${email} ${passwd}`);
		bcrypt.hash(passwd, saltRounds, function(err, hash) {
		//Now we can store the password hash in db.
		const insert = db.prepare('INSERT INTO subscribers (fname, email, passwd) VALUES ($1, $2, $3);');
		insert.run(fname, email, hash);
		insert.finalize();
	
		const query = db.prepare('SELECT id, fname, email, passwd FROM subscribers ORDER BY id DESC LIMIT 5;');
		
		query.all(function(error, rows){
		if(error){
			console.log(error);
			res.status(400).json(error);
		}
		else{
			console.log(rows);
			res.status(200).json(rows);
		}	
		});
		});
		
	}
});	