CREATE TABLE subscribers(
  id integer primary key autoincrement,
  fname varchar(50),
  email varchar(50),
  passwd varchar
);